# 生图提示词模板

每张图单独生成。根据正文内容替换变量，不要把多张图拼在一起。

每次调用都把 `assets/subject.png` 实际作为图片输入传入，具体参数见 `SKILL.md` 的“每次调用都附原图”。下面的文字模板不能替代附图；不要在没有图片输入时仅凭文件名或角色描述生成。`assets/subject-three-view.png` 只是兼容旧提示词的同图副本。忽略参考图里的棋盘格背景，只提取角色本体。

下面的单张新配图模板假设“输入图 1”就是角色原图。如果有多张参考图，按本次实际输入顺序修改图号并标明各图用途；填完变量再提交。

```text
Generate one standalone 16:9 horizontal Chinese article illustration.

Image inputs:
Input image 1 is the original 小黄 character and the sole authority for its appearance. Extract and reuse its character design; create the surrounding scene. Do not treat the filename or a previous generated illustration as the character reference. Ignore the checkerboard surrounding the character. The supplied image takes precedence over verbal approximations of its shape.

Visual DNA:
Pure white background. Minimalist black hand-drawn line art. Slightly wobbly pen lines. Lots of empty white space. Sparse red/orange/blue handwritten Chinese annotations. Clean absurd product-sketch feeling. No gradients, no shadows, no paper texture, no complex background, no commercial vector style, no PPT infographic look, no cute mascot poster, no children's illustration, no realistic UI.

Recurring IP character required:
Use 小黄 from input image 1. Preserve the actual front-facing central body silhouette, top-left black loop, broken contour strokes and overlaps, asymmetric left/right waves, bottom contour, and the exact shapes, proportions, placement and spacing of the eyes and pupils shown in that image. Preserve its actual yellow fill boundary, including existing gaps and spill outside the outline; do not normalize it or invent new gaps. No mouth, eyebrows, clothes or new facial features. Keep the body upright and frontal by default; express the action through the thin arms, legs and surrounding objects. Arms and legs may bend or change reach, but do not stretch, squash, smooth, mirror or redesign the central body. Make the character large enough to inspect its identifying details. 小黄 must perform the core conceptual action, not decorate the scene. Keep the serious, deadpan expression. Do not replace it with a generic blob, cloud, fluffy ball, sun, emoji or mascot.

Theme:
{正文配图主题}

Structure type:
{结构类型：Workflow / 系统局部 / 前后对比 / 角色状态 / 概念隐喻 / 方法分层 / 地图路线 / 小漫画分镜}

Core idea:
{这张图要表达的核心意思}

Composition:
{具体画面：小黄在哪里、正在做什么、主要物件是什么、信息如何流动}

Suggested elements:
{元素1} / {元素2} / {元素3} / {元素4}

Chinese handwritten labels:
{标注词1} / {标注词2} / {标注词3} / {标注词4} / {可选标注词5}

Color use:
Black for main line art, outlines, objects, and handwriting. Yellow only for 小黄's body. Orange for main flow/path/arrows. Red only for key warnings/problems/results. Blue only for secondary notes or feedback/system state.

Constraints:
One image explains only one core structure. Keep the main subject around 40%-60% of the canvas. Preserve at least 35% blank white space. Use at most 5-8 short handwritten Chinese labels. Do not write a title in the top-left corner. Do not write the structure type on the image. Do not make it a formal diagram, course slide, or dense explainer. Do not copy prior examples or reuse known case compositions unless explicitly requested; invent a fresh visual metaphor for this specific article. It should be clear but not instructional, interesting but not childish, strange but clean. Match every 小黄 to input image 1, including the original silhouette, top-left loop, contour strokes, eyes and actual yellow fill boundary. Avoid extra tiny characters whose identity details cannot be preserved.
```

## 图像编辑提示

每次编辑附带两张图：输入图 1 是待改图，输入图 2 是 `assets/subject.png` 原图。若实际顺序不同，先调整以下图号。不要只传待改图，否则上一次生成的形象偏差会被继承。

去掉左上角标题：

```text
Edit input image 1. Input image 2 is the original 小黄 identity reference, not a request to redraw the character. Remove only the handwritten title "{要删除的文字}" and its underline from the top-left corner. Fill that area with the same clean white background, matching the surrounding blank paper. Preserve everything else exactly: characters, labels, paths, line style, composition, aspect ratio, and image quality. Do not add any new text or objects.
```

修正形象偏差：

```text
Edit input image 1. Input image 2 is the original 小黄 character and the sole identity reference. Correct only these observed mismatches: {与原图对照后确认的具体偏差}. Match the original body's silhouette, contour strokes, eyes and actual yellow fill boundary from input image 2. Preserve the scene, labels, object positions, framing and all already-correct character details in input image 1. Keep limb interaction with the scene where possible; do not deform the central body to fit the pose. Do not introduce the checkerboard background. Do not redesign the character or add new details.
```

增强怪诞感：

```text
Edit the illustration in input image 1, keeping the same core meaning and simple layout, but make 小黄 more central to the conceptual action. 小黄 should be doing the strange work that explains the idea, not standing beside the diagram. Use input image 2 as the sole character identity reference. Preserve its body silhouette, top-left loop, contour strokes, asymmetric waves, actual yellow fill boundary, and the shapes and placement of the eyes. Adjust arms, legs and interaction with the main object for the action; do not redesign, squash or stretch the central body. Keep it clean, sparse, hand-drawn, deadpan and not cute.
```
